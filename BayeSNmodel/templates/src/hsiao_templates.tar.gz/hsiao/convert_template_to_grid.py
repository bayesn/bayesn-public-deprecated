#!/usr/bin/env python
import sys
import os
import numpy as np
import scipy.interpolate as sp
import astropy.table as at
import matplotlib.pyplot as plt
import h5py

def main():
    infile = 'snflux_1a.dat'
    indata = at.Table.read(infile, format='ascii', names=['phase','wave','flux'])
    phase  = np.array(sorted(np.unique(indata['phase'])))
    maxind = indata['phase'] == 0.
    wave   = np.array(sorted(indata['wave'][maxind]))
    if np.any(np.diff(wave) <= 0):
        message = 'Wavelength array is not monotonic'
        raise RuntimeError(message)

    nphase = len(phase)
    nwave  = len(wave)
    flux   = indata['flux'].reshape(nphase, nwave)
    phase  = phase[1:]
    nphase = len(phase)
    flux   = flux[1:,:]

    fig    = plt.figure(figsize=(6,15))
    ax = fig.add_subplot(111)
    pmax = phase.max()
    for i, p in enumerate(phase):
        tf = flux[i,:]
        norm = np.abs(tf.max())
        ax.plot(wave, tf/norm + p , color='k', linestyle='-')
    ax.set_xlabel(r'$\log$ Wavelength ($\lambda$)', fontsize='x-large')
    ax.set_ylabel(r'$F_{\lambda} + c$', fontsize='x-large')
    fig.tight_layout(rect=[0,0,1,1])
    fig.savefig('hsiao.pdf')

    outfile = '../../hsiao.h5'
    with h5py.File(outfile,'w') as f:
        grp = f.create_group('default')
        grp.create_dataset('phase',data=phase)
        grp.create_dataset('wave',data=wave)
        grp.create_dataset('flux',data=flux)


if __name__=='__main__':
    sys.exit(main())
